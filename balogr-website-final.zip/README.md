# Balogr Website

Balogr website based on the supplied design screenshots.

## Already configured
- Gumroad payment/product URL: https://earnify81.gumroad.com/l/tmhdh
- WhatsApp: +91 8769841043
- Product buttons (Starter / PRO / MAX) open the Gumroad page.
- Start Earning opens the Gumroad page.
- Tool/contact buttons open WhatsApp.

## How to publish on GitHub Pages

1. Open GitHub and create a new repository, for example `balogr`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and **/ (root)**, then Save.
6. GitHub will give you a temporary `github.io` website address.
7. To use `balogr.com`, open **Settings → Pages → Custom domain**, enter `balogr.com`, and save.
8. At your domain registrar, add the DNS records that GitHub shows for your repository. DNS changes can take some time to propagate.

## Important
The Gumroad URL is used as the checkout/product destination. Gumroad handles the payment and delivery flow on its side.

WhatsApp link:
https://wa.me/918769841043

If you change your Gumroad product later, replace the old URL in `index.html` with the new Gumroad URL.
